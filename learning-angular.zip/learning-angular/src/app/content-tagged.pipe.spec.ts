import { ContentTaggedPipe } from './content-tagged.pipe';

describe('ContentTaggedPipe', () => {
  it('create an instance', () => {
    const pipe = new ContentTaggedPipe();
    expect(pipe).toBeTruthy();
  });
});
