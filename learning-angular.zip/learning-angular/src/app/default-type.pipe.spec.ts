import { DefaultTypePipe } from './default-type.pipe';

describe('DefaultTypePipe', () => {
  it('create an instance', () => {
    const pipe = new DefaultTypePipe();
    expect(pipe).toBeTruthy();
  });
});
